export declare function loadTemplate(): string;
